function toggleChat() {
  const box = document.getElementById("chatbot-box");
  box.style.display = (box.style.display === "block") ? "none" : "block";

  // Load categories only the first time
  if (box.style.display === "block" && !document.querySelector(".chat-message")) {
    loadCategories();
  }
}

// Show main categories
function loadCategories() {
  const chatBody = document.getElementById("chat-body");
  chatBody.innerHTML = ""; // reset

  const categories = ["Admission Information", "Tuition Fees", "Campus Life"];

  categories.forEach(cat => {
    const btn = document.createElement("button");
    btn.className = "faq-btn";
    btn.innerText = cat;
    btn.onclick = () => loadQuestions(cat);
    chatBody.appendChild(btn);
  });
}

// Show questions under category
function loadQuestions(category) {
  const chatBody = document.getElementById("chat-body");
  chatBody.innerHTML = ""; // reset

  const questions = {
    "Admission Information": [
      { q: "How do I apply?", a: "You can apply online via our admissions portal." },
      { q: "What are the requirements?", a: "You’ll need transcripts, ID, and an application form." }
    ],
    "Tuition Fees": [
      { q: "How much is tuition?", a: "Average tuition is $1,500 per semester." },
      { q: "Do you offer scholarships?", a: "Yes, we have academic and sports scholarships." }
    ],
    "Campus Life": [
      { q: "Are there dormitories?", a: "Yes, dorms are available for local and international students." },
      { q: "What clubs are there?", a: "We have sports, arts, music, and tech clubs." }
    ]
  };

  questions[category].forEach(item => {
    const btn = document.createElement("button");
    btn.className = "faq-btn";
    btn.innerText = item.q;
    btn.onclick = () => showConversation(item.q, item.a);
    chatBody.appendChild(btn);
  });
}

// Display Q&A in Messenger style
function showConversation(question, answer) {
  const chatBody = document.getElementById("chat-body");

  // User bubble
  const userMsg = document.createElement("div");
  userMsg.className = "chat-message user";
  userMsg.innerText = question;
  chatBody.appendChild(userMsg);

  // AI bubble
  const aiMsg = document.createElement("div");
  aiMsg.className = "chat-message ai";
  aiMsg.innerText = answer;
  chatBody.appendChild(aiMsg);

  chatBody.scrollTop = chatBody.scrollHeight; // auto-scroll
}

