
function toggleChat() {
  const box = document.getElementById("chatbot-box");

  
  box.style.display = (box.style.display === "block") ? "none" : "block";

  
  if (box.style.display === "block" && !document.querySelector(".chat-message")) {
    loadCategories();
  }
}


function loadCategories() {
  const chatBody = document.getElementById("chat-body");
  chatBody.innerHTML = ""; 

  const categories = ["Admission Information", "Tuition Fees", "Campus Life"];

  categories.forEach(cat => {
    const btn = document.createElement("button");
    btn.className = "faq-btn";
    btn.innerText = cat;
    btn.onclick = () => loadQuestions(cat);
    chatBody.appendChild(btn);
  });
}


function loadQuestions(category) {
  const chatBody = document.getElementById("chat-body");
  chatBody.innerHTML = ""; 

  const questions = {
    "Admission Information": [
      { q: "How do I apply?", a: "📌 You can apply online via our admissions portal." },
      { q: "What are the requirements?", a: "📋 You’ll need transcripts, ID, and an application form." }
    ],
    "Tuition Fees": [
      { q: "How much is tuition?", a: "💰 Average tuition is $1,500 per semester." },
      { q: "Do you offer scholarships?", a: "🎓 Yes, we offer academic and sports scholarships." }
    ],
    "Campus Life": [
      { q: "Are there dormitories?", a: "🏠 Yes, dorms are available for local and international students." },
      { q: "What clubs are there?", a: "🎶 We have sports, arts, music, and tech clubs." }
    ]
  };

  
  const backBtn = document.createElement("button");
  backBtn.className = "faq-btn back-btn";
  backBtn.innerText = "⬅ Back to Categories";
  backBtn.onclick = loadCategories;
  chatBody.appendChild(backBtn);

  // kuan sa question
  questions[category].forEach(item => {
    const btn = document.createElement("button");
    btn.className = "faq-btn";
    btn.innerText = item.q;
    btn.onclick = () => showConversation(item.q, item.a);
    chatBody.appendChild(btn);
  });
}

// Q&A 
function showConversation(question, answer) {
  const chatBody = document.getElementById("chat-body");

  // User bubble
  const userMsg = document.createElement("div");
  userMsg.className = "chat-message user";
  userMsg.innerText = question;
  chatBody.appendChild(userMsg);

  // AI bubble 
  setTimeout(() => {
    const aiMsg = document.createElement("div");
    aiMsg.className = "chat-message ai";
    aiMsg.innerText = answer;
    chatBody.appendChild(aiMsg);

    chatBody.scrollTop = chatBody.scrollHeight; // auto-scroll
  }, 500);
}
